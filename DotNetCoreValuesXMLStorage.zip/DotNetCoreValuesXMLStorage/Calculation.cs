﻿using System;
using System.Xml;
using System.Xml.Serialization;

namespace DotNetCoreValuesXMLStorage
{
    [Serializable]
    public class Calculation
    {

        public Calculation() { } //Needs an empty constructor to serialize!!!

        public Calculation(Decimal num1, Decimal num2, String op)
        {
            this.first = num1;
            this.second = num2;
            this.operation = op;
            this.message = null;
            switch (op)
            {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    if (num2 == 0m)
                    {
                        message += " Undefined!!! [Cannot divide by zero]";
                    }
                    else
                    {
                        result = num1 / num2;
                    }
                    break;
            }
            if (this.message == null)
            {
                this.message = result.ToString();
            }
        }

        private Decimal first;

        public Decimal First
        {
            get { return first; }
            set { first = value; }
        }

        private Decimal second;

        public Decimal Second
        {
            get { return second; }
            set { second = value; }
        }

        private Decimal result;

        public Decimal Result
        {
            get { return result; }
            set { result = value; }
        }

        private String operation;

        public String Operation
        {
            get { return operation; }
            set { operation = value; }
        }

        private String message;

        public String Message
        {
            get { return message; }
            set { message = value; }
        }

        public String DisplayEntry()
        {
            String toReturn = "";
            toReturn += "Calculation: " + first + " " + operation + " " + second + " = " + message;
            return toReturn;
        }

    }
}
