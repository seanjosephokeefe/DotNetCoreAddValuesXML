﻿using System;
using System.Collections.Generic;
using static System.Console;
using System.IO;
using System.Xml.Serialization;
using System.Diagnostics;

namespace DotNetCoreValuesXMLStorage
{
    class Program
    {
        // Get the current directory.
        static string path = Directory.GetCurrentDirectory();
        static String xmlPath = path + "\\xml\\data.xml";

        static void Main(string[] args)
        {
            char choice = (char)0;
            String menu = "";
            menu += "***************************************\n";
            menu += "       Serialization Main Menu\n";
            menu += "***************************************\n";
            menu += "a) Add a calculation\n";
            menu += "v) View all calculations\n";
            menu += "q) quit\n";
            menu += "\nMenu selection: ";
            do
            {
                Clear();
                choice = Char.ToLower(HelperClass.GetCharacter(menu));
                switch (choice.ToString().ToLower())
                {
                    case "a":
                        AddCalculation();
                        break;
                    case "v":
                        ViewAllCalculations();
                        break;
                    case "q":
                        HelperClass.PressAnyKey("Okay, goodbye. Press any key to end!!!");
                        break;
                    default:
                        HelperClass.PressAnyKey("That is not a valid choice. Press any key to end!!!");
                        break;
                }
            } while (choice.ToString().ToLower() != "q");
        }

        static void AddCalculation()
        {
            Clear();
            Decimal num1 = HelperClass.GetDecimal("Enter the first number for your calculation: ");
            String op;
            do
            {
                op = HelperClass.GetCharacter("Enter an operator [+,-,*,/]: ").ToString();
                if ((op != "+") && (op != "-") && (op != "*") && (op != "/"))
                {
                    WriteLine("That is not a valid option [+,-,*,/], please try again.");
                }
            } while ((op != "+") && (op != "-") && (op != "*") && (op != "/"));
            Decimal num2 = HelperClass.GetDecimal("Enter the second number for your calculation: ");
            AddScoresXMLWriter(new Calculation(num1, num2, op));
            HelperClass.PressAnyKey("Calculation has been added. Press any key to continue.");
        }

        static void ViewAllCalculations()
        {
            PrintObject(GetScoresXMLReader());
        }

        static void AddScoresXMLWriter(Calculation calc)
        {
            List<Calculation> cList = GetScoresXMLReader();
            cList.Add(calc);
            var writer = new System.Xml.Serialization.XmlSerializer(typeof(List<Calculation>));
            var xmlFile = new System.IO.StreamWriter(xmlPath);
            writer.Serialize(xmlFile, cList);
            xmlFile.Close();
        }

        static List<Calculation> GetScoresXMLReader()
        {
            List<Calculation> calcs = new List<Calculation>();
            try
            {
                System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(typeof(List<Calculation>));
                System.IO.StreamReader file = new System.IO.StreamReader(xmlPath);
                calcs = (List<Calculation>)reader.Deserialize(file);
                file.Close();
            }
            catch (FileNotFoundException fex)
            {
                Debug.Write(fex.Message);
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
            }
            return calcs;
        }

        static void PrintObject(List<Calculation> calcs)
        {
            Clear();
            WriteLine("Calculations:\n");
            if (calcs.Count == 0)
            {
                WriteLine("There are no calculations to display.\n");
            }
            else
            {
                calcs.ForEach(calc =>
                {
                    WriteLine(calc.DisplayEntry());
                });
            }
            WriteLine();
            HelperClass.PressAnyKey("Press any key to continue.");
        }

    }
}
